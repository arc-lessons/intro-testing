def mean(num_list):
    ''' Function to calculate the mean of a list of numbers
    Usage: mean(list_of_numbers)
    Checks that length of list is not 0
    returns sum(list_of_numbers)/len(list_of_numbers)'''
    assert len(num_list) != 0
    return sum(num_list) / len(num_list)

def mean_exc(num_list):
    ''' Function to calculate the mean of a list of numbers
    Usage: mean(list_of_numbers)
    Raises exception if length of list is 0
    returns sum(list_of_numbers)/len(list_of_numbers)'''

    if len(num_list) == 0 :
      raise Exception("The algebraic mean of an empty list is undefined.\
                       Please provide a list of numbers")
    else :
      return sum(num_list)/len(num_list)

def mean_try(num_list):
    ''' Function to calculate the mean of a list of numbers
    Usage: mean(list_of_numbers)
    Raises exception on ZeroDivisionError if length of list is 0
    returns sum(list_of_numbers)/len(list_of_numbers)'''
    try:
        return sum(num_list)/len(num_list)
    except ZeroDivisionError as detail :
        msg = "The algebraic mean of an empty list is undefined. Please provide a list of numbers."
        raise ZeroDivisionError(detail.__str__() + "\n" +  msg)

def main():
    ''' Simple check of mean:
    calls mean on:
    numbers = [1, 2, 3, 4, 5],
    returning the mean, 3.0
    nonumbers = []
    which causes an assertion error due to passing an empty list'''

    numbers = [1, 2, 3, 4, 5]

    mean(numbers)

    nonumbers = []

    mean(nonumbers)

if __name__ == '__main__':
    #Ensure that main is only called if called as a script
    #Not executed if mean is imported
    main()
