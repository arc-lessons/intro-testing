def mean(num_list):
    ''' Function to calculate the mean of a list of numbers
    Usage: mean(list_of_numbers)
    returns sum(list_of_numbers)/len(list_of_numbers)
    Checks that length of list is not 0'''
    assert len(num_list) != 0
    return sum(num_list) / len(num_list)

def main():
    ''' Simple check of mean:
    calls mean on:
    numbers = [1, 2, 3, 4, 5],
    returning the mean, 3.0
    nonumbers = []
    which causes an assertion error due to passing an empty list'''

    numbers = [1, 2, 3, 4, 5]

    mean(numbers)

    nonumbers = []

    mean(nonumbers)

if __name__ == '__main__':
    #Ensure that main is only called if called as a script
    #Not executed if mean is imported
    main()
