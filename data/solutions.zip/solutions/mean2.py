def mean(num_list):
    assert len(num_list) != 0
    return sum(num_list) / len(num_list)

numbers = [1, 2, 3, 4, 5]

mean(numbers)

nonumbers = []

mean(nonumbers)
