def mean(num_list):
    assert len(num_list) != 0
    return sum(num_list) / len(num_list)

def main():

    numbers = [1, 2, 3, 4, 5]

    mean(numbers)

    nonumbers = []

    mean(nonumbers)

if __name__ == '__main__':
    main()
